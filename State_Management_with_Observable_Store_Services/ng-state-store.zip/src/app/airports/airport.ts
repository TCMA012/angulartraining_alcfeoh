export interface Airport {
  code: string;
  name: string;
}